var apasate = {};

function generateWord()
{
    var random;
    var cuvant = "";

    for(let i=0; i<7; i++)
    {
        random = Math.trunc(97 + 25 * Math.random());
        cuvant += String.fromCharCode(random);
    }

    return cuvant;
}


window.onload = function(){

// exercitiul 1

document.getElementById("minim").onclick = function(){
    var rand;
    var lista = document.getElementById("lista");
    var randuri = lista.getElementsByTagName("li");
    if(randuri.length > 0)
    {
        rand = randuri[0];
        for(let i=0; i<randuri.length; i++)
        {
            if(randuri[i].innerHTML.length < rand.innerHTML.length)
                rand = randuri[i];
            if(randuri[i].innerHTML.length == rand.innerHTML.length && randuri[i].innerHTML.localeCompare(rand.innerHTML) == -1)
                rand = randuri[i];
        }
        rand.remove();
    }
};

document.getElementById("adrandom").onclick = function(){
    var lista = document.getElementById("lista");
    var li = document.createElement("li");
    li.innerHTML = generateWord();
    lista.appendChild(li);
};

document.getElementById("adclasa").onclick = function(){
    var lista = document.getElementById("lista");
    var randuri = document.getElementsByTagName("li");
    var gasit = 0;
    for(let rand of randuri)
    {
        if(!rand.classList.contains('albastru'))
        {
            gasit = 1;
            rand.classList.add('albastru');
            break;
        }
    }
    if(gasit == 0)
    {
        alert("Toate elementele sunt albastre!");
    }
};

// exercitiul 2


//punctul a

document.addEventListener("keydown", function(e)
{
    if(e.key === 'a')
    {
        var span = document.getElementById("ex2");
        var paragrafe = span.getElementsByTagName("p");
        for(let para of paragrafe)
        {
            if(para.innerHTML[0] == 'a' || para.innerHTML[0] == 'A')
            {
                para.classList.add("paragraf-albastru");
            }
        }
    }
});

document.addEventListener("keyup", function(e)
{
    if(e.key === 'a')
    {
        var span = document.getElementById("ex2");
        var paragrafe = span.getElementsByTagName("p");
        for(let para of paragrafe)
        {
            if(para.classList.contains("paragraf-albastru"))
            {
                para.classList.remove("paragraf-albastru");
            }
        }
    }
});

// fac separat pentru punctul b ca sa se vada diferenta

document.addEventListener("keydown", function(e){
    if(e.key === 'B') // shift + b = B mare
    {
        var span = document.getElementById("ex2");
        var paragrafe = span.getElementsByTagName("p");
        for(let para of paragrafe)
        {
            if(para.style.fontWeight != "bold")
                para.style.fontWeight = "bold";
            else
                para.style.fontWeight = "normal";
        }
    }
});

// punctul c

let chei = {
    d: false,
    Control: false,
    Shift: false,
    Alt: false,
};

document.addEventListener("keydown", function(e){
    if(e.key === 'd')
    {
        chei.d = true;
        console.log("am apasat d");
    }
    if(e.key === 'Control')
    {
        chei.Control = true;
        console.log("am apasat ctrl");
    }
    if(e.key === 'Shift')
    {
        chei.Shift = true;
        console.log("am apasat shift");
    }
    if(e.key === 'Alt')
    {
        chei.Alt = true;
        console.log("am apasat alt");
    }
    if(chei.d && chei.Control && chei.Shift && chei.Alt)
    {
        console.log("sunt apasate toate");
    }
 });

document.addEventListener("keyup", function(e){
    if(e.key === 'd')
    {
        chei.d = false;
        console.log("am scos d");
    }
    if(e.key === 'Control')
    {
        chei.Control = false;
        console.log("am scos ctrl");
    }
    if(e.key === 'Shift')
    {
        chei.Shift = false;
        console.log("am scos shift");
    }
    if(e.key === 'Alt')
    {
        chei.Alt = false;
        console.log("am scos alt");
    }
});
 
}